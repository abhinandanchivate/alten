package com.example.springbootexceptionhandling.apierror;

public abstract class ApiSubError {

}
